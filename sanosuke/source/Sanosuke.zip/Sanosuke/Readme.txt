Sanosuk� Sagara v0.6

by Dj Apx
   dj_apx@yahoo.fr


Installation:
- Move all folders into your LF2-directory
- Add these lines to data.txt (to the object-part):

  id:  91   type: 0  file: sprite\sanosuke\sanosuke.dat
  id:  911  type: 1  file: sprite\sanosuke\zanbato.dat
  id:  912  type: 3  file: sprite\sanosuke\zanbato_get.dat
  id:  913  type: 3  file: sprite\sanosuke\sanosuke_ball.dat

- Have fun playing!


Please don't steal !!!

Please give me the credits if you copy.
Sanosuke Sagara, Zanbato and Rurouni Kenshin (alias
Samurai X) are properties of Nobuhiro Watsuki. You own
no right on these.

C U Soon people !!

______________________________________________________________________

                           www.lf-empire.de

                      Little Fighter EMPIRE v8.0
                           ~ all you need ~